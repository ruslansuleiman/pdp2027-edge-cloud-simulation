# Расширенная event-driven модель PDP 2027

Этот пакет содержит финальную event-driven версию эксперимента и артефакты, используемые в обновлённой статье. Модель структурно подробнее первоначального прототипа, но не откалибрована по реальному оборудованию; старые prototype results не включены в таблицы новой статьи, поскольку меняются сразу несколько предположений модели.

Для PDP 2027 review загружайте только `PDP2027_submission_anonymous.pdf`: конференция использует double-blind review. Имя автора, affiliation и контактные данные указываются отдельно в EasyChair, не в PDF. Остальные артефакты этого пакета не нужно загружать в поле manuscript. PDF в исправленном комплекте пересобран после дополнительного аудита формулировок и статистической оговорки.

## Модель

- Event calendar обрабатывает arrivals, завершения передачи/вычисления, propagation и поступление в следующие очереди.
- Все входные payloads используют общий ingress-link, все выходные payloads — отдельный общий egress-link. Линки независимы (full-duplex); по умолчанию пропускная способность каждого направления — 100 Mbit/s. Общие links и node-specific links — FIFO. Сериализация вычисляется как `8 × MB / Mbit/s`; propagation не занимает канал.
- После общей access link задание использует node-specific uplink/downlink. Actual propagation delay применяется один раз после node-specific transfer в каждом направлении; random jitter для выполнения задачи берётся из `U(0, 0.2 × one-way propagation)`, с согласованными seed для сравниваемых политик. SEC до маршрутизации не знает будущий jitter: он использует математическое ожидание uniform distribution.
- CPU — work-conserving pool с общей FIFO waiting queue: edge_1 — 2×450 MI/s, edge_2 — 2×350 MI/s, cloud — 8×300 MI/s. Каждая задача использует одно ядро за раз. Суммарная capacity узла сохраняет 900/700/2400 MI/s, но параллелизм и per-task service меняются.
- Очереди неограниченные, потерь нет. Окно arrivals конечно; после него все принятые задачи завершаются. Это finite-cohort/drain эксперимент, не stationary-queue измерение.
- SEC использует population means для новой задачи и predicted tail reservations для уже существующих ресурсов. Это myopic heuristic, не oracle/look-ahead; реальные multicore completion events могут отличаться от упрощённого prediction order.

## Сценарии

Синтетические Poisson arrivals: 2 или 6 задач/с; clipped log-normal workload/data sizes; arrival window 120 s. Основные сценарии: propagation multiplier 1 или 3; по 20 paired replications. Seed для репликации `r` равен `20261009 + (r-1)`. Sensitivity: 6 задач/с, multiplier 1, ingress и egress одновременно 50/100/200 Mbit/s. Средний offered input payload при 6 задачах/с ≈86.1 Mbit/s; поэтому сценарий ingress 50 Mbit/s перегружен по среднему входящему потоку.

## Запуск и тестирование

В каталоге модели:

```bash
python3 -m unittest -v test_edge_cloud_sim_extended.py
python3 edge_cloud_sim_extended.py
```

Результаты: `extended_replications.csv`, `extended_summary.csv`, `extended_paired.csv`, `extended_routes.csv`, `extended_raw.csv`, `extended_access_sensitivity_replications.csv`, `extended_access_sensitivity_summary.csv`, `extended_access_sensitivity_paired.csv`, `extended_plot.png`. Raw trace содержит task-level stages, policy, seed, replication, arrival rate, access capacities, node and actual CPU core ID. The raw trace and summaries can be checked with `audit_extended_results.py`.

Тесты проверяют serialization, FCFS shared links, full-duplex direction independence, освобождение link после serialization, однократные propagation/jitter, ожидаемый jitter в предикторе, concurrency двух ядер, drain конечного потока, сохранение всех заданий, детерминированность paired прогонов, CI-требование ровно 20 репликаций и раздельную агрегацию по ingress/egress capacity.
