#!/usr/bin/env python3
"""Independent consistency checks for the extended simulator output CSVs."""
from __future__ import annotations

import csv
import math
import statistics
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
T19 = 2.093024054
NODES = {
    "edge_1": {"delay": 0.010, "up": 40.0, "down": 80.0, "cores": 2, "core_rate": 450.0},
    "edge_2": {"delay": 0.015, "up": 25.0, "down": 50.0, "cores": 2, "core_rate": 350.0},
    "cloud": {"delay": 0.045, "up": 100.0, "down": 200.0, "cores": 8, "core_rate": 300.0},
}
POLICIES = ("round_robin", "shortest_estimated_completion")


def read_csv(name: str) -> list[dict[str, str]]:
    with (ROOT / name).open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def f(row: dict[str, str], key: str) -> float:
    return float(row[key])


def close(a: float, b: float, tol: float = 1e-7) -> bool:
    return math.isclose(a, b, rel_tol=tol, abs_tol=tol)


def mean_ci(values: list[float]) -> tuple[float, float, float]:
    if len(values) != 20:
        raise AssertionError(f"Expected 20 replications, got {len(values)}")
    mean = statistics.mean(values)
    margin = T19 * statistics.stdev(values) / math.sqrt(20)
    return mean, mean - margin, mean + margin


def check_summary(rep_rows: list[dict[str, str]], summary_rows: list[dict[str, str]], paired_rows: list[dict[str, str]]) -> None:
    by_group: dict[tuple, list[dict[str, str]]] = defaultdict(list)
    for row in rep_rows:
        key = (row["arrival_rate_tasks_per_s"], row["network_multiplier"], row["access_up_mbps"], row["access_down_mbps"], row["policy"])
        by_group[key].append(row)
    assert len(by_group) == len(summary_rows)
    summary_index = {(r["arrival_rate_tasks_per_s"], r["network_multiplier"], r["access_up_mbps"], r["access_down_mbps"], r["policy"]): r for r in summary_rows}
    for key, rows in by_group.items():
        row = summary_index[key]
        avg, lo, hi = mean_ci([f(x, "mean_latency_ms") for x in rows])
        assert close(avg, f(row, "mean_latency_ms"))
        assert close(lo, f(row, "ci95_low_ms"))
        assert close(hi, f(row, "ci95_high_ms"))

    scenarios = {(k[0], k[1], k[2], k[3]) for k in by_group}
    paired_index = {(r["arrival_rate_tasks_per_s"], r["network_multiplier"], r["access_up_mbps"], r["access_down_mbps"]): r for r in paired_rows}
    assert scenarios == set(paired_index)
    for scenario in scenarios:
        rrows = {int(r["replication"]): r for r in rep_rows if (r["arrival_rate_tasks_per_s"], r["network_multiplier"], r["access_up_mbps"], r["access_down_mbps"], r["policy"]) == (*scenario, "round_robin")}
        srows = {int(r["replication"]): r for r in rep_rows if (r["arrival_rate_tasks_per_s"], r["network_multiplier"], r["access_up_mbps"], r["access_down_mbps"], r["policy"]) == (*scenario, "shortest_estimated_completion")}
        assert set(rrows) == set(srows) == set(range(1, 21))
        diffs = [f(rrows[i], "mean_latency_ms") - f(srows[i], "mean_latency_ms") for i in range(1, 21)]
        mean, lo, hi = mean_ci(diffs)
        row = paired_index[scenario]
        assert close(mean, f(row, "mean_paired_difference_rr_minus_sec_ms"))
        assert close(lo, f(row, "paired_ci95_low_ms"))
        assert close(hi, f(row, "paired_ci95_high_ms"))
        rrmean = statistics.mean(f(x, "mean_latency_ms") for x in rrows.values())
        secmean = statistics.mean(f(x, "mean_latency_ms") for x in srows.values())
        reduction = 100 * (rrmean - secmean) / rrmean
        assert close(reduction, f(row, "relative_reduction_percent"))
        assert sum(d > 0 for d in diffs) == int(row["sec_better_replications"])


def check_raw(rows: list[dict[str, str]]) -> None:
    assert rows, "Raw task trace is empty"
    main_groups: dict[tuple, list[dict[str, str]]] = defaultdict(list)
    resources: dict[tuple, list[tuple[float, float, int]]] = defaultdict(list)
    paired_tasks: dict[tuple, dict[str, tuple]] = {}

    for row in rows:
        required = {"policy", "replication", "seed", "arrival_rate_tasks_per_s", "network_multiplier", "task_id", "compute_core_id"}
        assert required.issubset(row), f"Missing raw fields: {required - set(row)}"
        rate, net, rep = row["arrival_rate_tasks_per_s"], row["network_multiplier"], row["replication"]
        policy, seed, tid, node = row["policy"], row["seed"], int(row["task_id"]), row["node"]
        group = (rate, net, rep, seed, policy)
        main_groups[group].append(row)
        node_info = NODES[node]
        m = f(row, "network_multiplier")

        order_fields = ["arrival_s", "access_up_start_s", "access_up_finish_s", "node_up_start_s", "node_up_finish_s", "upload_arrival_s", "compute_start_s", "compute_finish_s", "node_down_start_s", "node_down_finish_s", "node_download_arrival_s", "access_down_start_s", "access_down_finish_s", "completion_s"]
        times = [f(row, key) for key in order_fields]
        assert all(b + 1e-8 >= a for a, b in zip(times, times[1:])), (group, tid, order_fields)
        assert close(f(row, "latency_ms"), 1000 * (f(row, "completion_s") - f(row, "arrival_s")))

        # Check all four serializations independently from raw payloads.
        expected_intervals = [
            ("access_up_start_s", "access_up_finish_s", 8 * f(row, "input_mb") / f(row, "access_up_mbps")),
            ("node_up_start_s", "node_up_finish_s", 8 * f(row, "input_mb") / node_info["up"]),
            ("node_down_start_s", "node_down_finish_s", 8 * f(row, "output_mb") / node_info["down"]),
            ("access_down_start_s", "access_down_finish_s", 8 * f(row, "output_mb") / f(row, "access_down_mbps")),
        ]
        for a, b, expected in expected_intervals:
            assert close(f(row, b) - f(row, a), expected), (group, tid, a, b)

        # Propagation and jitter are applied once, independently in each direction.
        low, high = node_info["delay"] * m, node_info["delay"] * m * 1.2
        for delta in (f(row, "upload_arrival_s") - f(row, "node_up_finish_s"), f(row, "node_download_arrival_s") - f(row, "node_down_finish_s")):
            assert low - 1e-8 <= delta <= high + 1e-8, (group, tid, delta, low, high)
        core = int(float(row["compute_core_id"]))
        assert 0 <= core < node_info["cores"]
        assert close(f(row, "compute_finish_s") - f(row, "compute_start_s"), f(row, "work_mi") / node_info["core_rate"])

        # Resource intervals must not overlap; access links are shared, node links and cores are per node.
        for name, start, finish in (
            ("access_up", "access_up_start_s", "access_up_finish_s"),
            ("access_down", "access_down_start_s", "access_down_finish_s"),
            (f"node_up:{node}", "node_up_start_s", "node_up_finish_s"),
            (f"node_down:{node}", "node_down_start_s", "node_down_finish_s"),
            (f"cpu:{node}:{core}", "compute_start_s", "compute_finish_s"),
        ):
            rkey = (rate, net, rep, seed, policy, name)
            resources[rkey].append((f(row, start), f(row, finish), tid))

        # Paired policies must process identical generated task attributes.
        base_key = (rate, net, rep, seed, tid)
        attrs = (f(row, "arrival_s"), f(row, "work_mi"), f(row, "input_mb"), f(row, "output_mb"))
        paired_tasks.setdefault(base_key, {})[policy] = attrs

    for group, task_rows in main_groups.items():
        ids = [int(r["task_id"]) for r in task_rows]
        assert len(ids) == len(set(ids)), f"Duplicate task IDs in {group}"
        assert len(task_rows) > 0
        if group[-1] == "round_robin":
            ordered = sorted(task_rows, key=lambda r: int(r["task_id"]))
            expected = ("edge_1", "edge_2", "cloud")
            for i, row in enumerate(ordered):
                assert row["node"] == expected[i % 3], (group, i, row["node"])
    for key, pair in paired_tasks.items():
        assert set(pair) == set(POLICIES), key
        assert pair[POLICIES[0]] == pair[POLICIES[1]], key

    for resource, intervals in resources.items():
        intervals.sort()
        for prev, cur in zip(intervals, intervals[1:]):
            assert cur[0] + 1e-8 >= prev[1], (resource, prev, cur)


def main() -> None:
    main_reps = read_csv("extended_replications.csv")
    main_summary = read_csv("extended_summary.csv")
    main_paired = read_csv("extended_paired.csv")
    check_summary(main_reps, main_summary, main_paired)
    check_raw(read_csv("extended_raw.csv"))

    sens_reps = read_csv("extended_access_sensitivity_replications.csv")
    sens_summary = read_csv("extended_access_sensitivity_summary.csv")
    sens_paired = read_csv("extended_access_sensitivity_paired.csv")
    check_summary(sens_reps, sens_summary, sens_paired)
    print(f"PASS: {len(main_reps)} main replication rows, {len(sens_reps)} sensitivity rows, and {len(read_csv('extended_raw.csv'))} task traces checked")
    print("PASS: paired task streams, latency accounting, serialization, propagation bounds, FCFS resources, CPU-core service, and 95% CIs")


if __name__ == "__main__":
    main()
