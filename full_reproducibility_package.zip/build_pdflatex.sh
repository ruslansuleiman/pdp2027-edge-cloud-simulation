#!/bin/sh
# Reference build with real pdfLaTeX (Times/Nimbus fonts, as in the original PDF).
# Requires a TeX Live with IEEEtran, e.g.:
#   docker run --rm --platform linux/amd64 -v "$PWD":/w -w /w ghcr.io/xu-cheng/texlive-alpine:latest sh build_pdflatex.sh
pdflatex -interaction=nonstopmode main_extended_FINAL.tex && pdflatex -interaction=nonstopmode main_extended_FINAL.tex && pdflatex -interaction=nonstopmode main_extended_FINAL.tex
