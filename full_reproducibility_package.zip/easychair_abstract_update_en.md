# EasyChair metadata for the corrected paper

**Title**

Round-Robin and Estimated-Completion Scheduling in a Shared-Network Edge--Cloud Simulation

**Abstract**

Edge--cloud task placement trades processing capacity against communication delay and queueing. We compare Round-Robin (RR) with a greedy, mean-based Shortest Estimated Completion (SEC) policy in an event-driven model with two edge nodes, one cloud node, shared full-duplex access links, node-specific links, and multicore CPU pools. Four combinations of arrival rate (2 or 6 tasks/s) and propagation multiplier (1 or 3) are evaluated using 20 paired replications. At 2 tasks/s, paired confidence intervals include zero, so no consistent policy advantage is detected. At 6 tasks/s, SEC reduces mean latency by 75.9–76.9% in the 100-Mbit/s access scenario. A high-load capacity sensitivity shows that the reduction varies from 1.8% at 50 Mbit/s to 81.1% at 200 Mbit/s; the 50-Mbit/s ingress is overloaded by the mean offered input traffic. Exploratory post-hoc comparisons indicate that a static capacity-weighted Round-Robin policy performs at least as well as SEC at 6 tasks/s in the tested scenarios. A variant that replaces estimated work and output sizes of queued jobs with population means has lower sample mean latency than the original SEC in each tested scenario; this exploratory comparison does not establish general dominance. Parameters and workloads are synthetic and uncalibrated. The finite-cohort results therefore support only conclusions about this model, not universal superiority or real-system performance.

**Keywords**

Edge-cloud computing; task scheduling; Round-Robin; estimated completion time; discrete-event simulation; end-to-end latency

Keep author name and affiliation in EasyChair author fields. Do not add them to the anonymous review PDF. This abstract is intended to match the corrected manuscript; replace the older abstract only if EasyChair still allows editing.
