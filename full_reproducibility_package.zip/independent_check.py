#!/usr/bin/env python3
"""Independent re-computation of statistics (numpy/scipy) from replication CSVs,
plus population means, per-node offered load and jitter-seed collision check."""
import csv, math, random, statistics
import numpy as np
from scipy import stats
import edge_cloud_sim_extended as sim

def rd(n): return list(csv.DictReader(open(n)))
def block(rows, rate, m, cap=None):
    out = {}
    for r in rows:
        if float(r["arrival_rate_tasks_per_s"]) == rate and float(r["network_multiplier"]) == m and (cap is None or float(r["access_up_mbps"]) == cap):
            out.setdefault(r["policy"], {})[int(r["replication"])] = r
    return out
rows = rd("extended_replications.csv") ; sens = rd("extended_access_sensitivity_replications.csv")
rng = np.random.default_rng(1)
print("scenario | mean diff | scipy t CI | bootstrap CI(10k) | Wilcoxon p | Shapiro p(diff) | sign wins")
for lab, src, rate, m, cap in [("2/s m1", rows, 2., 1., 100.), ("2/s m3", rows, 2., 3., 100.), ("6/s m1", rows, 6., 1., 100.), ("6/s m3", rows, 6., 3., 100.),
                              ("6/s m1 50", sens, 6., 1., 50.), ("6/s m1 200", sens, 6., 1., 200.)]:
    b = block(src, rate, m, cap)
    d = np.array([float(b["round_robin"][i]["mean_latency_ms"]) - float(b["shortest_estimated_completion"][i]["mean_latency_ms"]) for i in range(1, 21)])
    t = stats.t.interval(0.95, 19, loc=d.mean(), scale=stats.sem(d))
    bs = np.percentile([rng.choice(d, 20).mean() for _ in range(10000)], [2.5, 97.5])
    print(lab, "|", round(d.mean(), 1), "|", [round(x, 1) for x in t], "|", [round(x, 1) for x in bs], "|", f"{stats.wilcoxon(d).pvalue:.2g}", "|", f"{stats.shapiro(d).pvalue:.2g}", "|", int((d > 0).sum()))
print("t crit df=19:", stats.t.ppf(0.975, 19), "vs hard-coded", sim.T_CRITICAL_95_DF19)
# population means (Monte Carlo, seed 7, 300k draws as in paper)
r = random.Random(7); N = 300000
w = i = o = 0.0
for _ in range(N):
    w += min(1800., max(80., r.lognormvariate(math.log(450), .65)))
    i += min(20., max(.05, r.lognormvariate(math.log(1.2), .9)))
    o += min(5., max(.01, r.lognormvariate(math.log(.12), .8)))
print("MC means", w / N, i / N, o / N, "(code uses", sim.MEAN_WORK_MI, sim.MEAN_INPUT_MB, sim.MEAN_OUTPUT_MB, ")")
# offered load per node under RR (1/3 each), WRR and observed SEC shares
routes = rd("extended_routes.csv")
for pol in sim.POLICIES:
    sh = {}
    for x in routes:
        if float(x["arrival_rate_tasks_per_s"]) == 6 and float(x["network_multiplier"]) == 1 and x["policy"] == pol:
            sh.setdefault(x["node"], []).append(float(x["share"]))
    print(pol, {k: round(statistics.mean(v), 3) for k, v in sh.items()})
lam = 6.0
for name, share in (("RR", (1/3, 1/3, 1/3)),):
    for n, s in zip(sim.NODES, share):
        cpu = lam * s * sim.MEAN_WORK_MI / n.aggregate_compute_mi_s
        up = lam * s * sim.MEAN_INPUT_MB * 8 / n.uplink_mbps
        dn = lam * s * sim.MEAN_OUTPUT_MB * 8 / n.downlink_mbps
        print(name, n.name, f"cpu rho={cpu:.2f} uplink rho={up:.2f} downlink rho={dn:.2f}")
print("shared ingress rho @100:", lam * sim.MEAN_INPUT_MB * 8 / 100, " egress:", lam * sim.MEAN_OUTPUT_MB * 8 / 100)
for lam2 in (2.0,):
    for n in sim.NODES:
        print("lam2 RR", n.name, f"cpu {lam2/3*sim.MEAN_WORK_MI/n.aggregate_compute_mi_s:.2f} up {lam2/3*sim.MEAN_INPUT_MB*8/n.uplink_mbps:.2f}")
# jitter seed collisions
seen = {}; col = 0
for rep in range(20):
    for t in range(0, 1000):
        for nd in range(3):
            for st in (1, 2):
                k = (sim.BASE_SEED + rep) * 1000003 + t * 9176 + nd * 131 + st
                if k in seen: col += 1
                seen[k] = 1
print("jitter seed collisions:", col)
