#!/usr/bin/env python3
"""Supplementary (part B) experiments: information-restricted SEC and weighted RR.

Results are written to supplementary_*.csv and are reported separately from
the main RR-vs-SEC experiment (whose code path and outputs are unchanged).
"""
import csv, math, statistics
import edge_cloud_sim_extended as sim

T19 = sim.T_CRITICAL_95_DF19
ALL = sim.ALL_POLICIES

def paired(a, b):
    d = [x - y for x, y in zip(a, b)]
    m = statistics.mean(d); h = T19 * statistics.stdev(d) / math.sqrt(len(d))
    return m, m - h, m + h, sum(x > 0 for x in d)

def main():
    scen = [(2.0, 1.0, 100.0), (2.0, 3.0, 100.0), (6.0, 1.0, 100.0), (6.0, 3.0, 100.0),
            (6.0, 1.0, 50.0), (6.0, 1.0, 200.0)]
    rows, comp = [], []
    for rate, m, cap in scen:
        reps, _, routes = sim.evaluate(rate, m, sim.SIMULATION_DURATION_S, sim.REPLICATIONS, cap, cap, False, ALL)
        lat = {p: [r["mean_latency_ms"] for r in reps if r["policy"] == p] for p in ALL}
        p95 = {p: [r["p95_latency_ms"] for r in reps if r["policy"] == p] for p in ALL}
        cloud = {p: statistics.mean(r["share"] for r in routes if r["policy"] == p and r["node"] == "cloud") for p in ALL}
        for p in ALL:
            mean = statistics.mean(lat[p]); h = T19 * statistics.stdev(lat[p]) / math.sqrt(20)
            rows.append(dict(rate=rate, multiplier=m, access_mbps=cap, policy=p, mean_ms=mean,
                             ci_low=mean - h, ci_high=mean + h, mean_p95_ms=statistics.mean(p95[p]), cloud_share=cloud[p]))
        for a, b in [("round_robin", "weighted_round_robin"), ("round_robin", "sec_mean_reservation"),
                     ("weighted_round_robin", "shortest_estimated_completion"),
                     ("shortest_estimated_completion", "sec_mean_reservation"),
                     ("weighted_round_robin", "sec_mean_reservation")]:
            d, lo, hi, w = paired(lat[a], lat[b])
            comp.append(dict(rate=rate, multiplier=m, access_mbps=cap, a_minus_b=f"{a} - {b}",
                             mean_diff_ms=d, ci_low=lo, ci_high=hi, b_better_reps=w))
    for name, data in (("supplementary_policies.csv", rows), ("supplementary_paired.csv", comp)):
        with open(name, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=list(data[0])); w.writeheader(); w.writerows(data)
    for r in rows: print({k: (round(v, 1) if isinstance(v, float) else v) for k, v in r.items()})
    for r in comp: print({k: (round(v, 1) if isinstance(v, float) else v) for k, v in r.items()})

if __name__ == "__main__":
    main()
